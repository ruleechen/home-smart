| Example #     | Description   |
| ------------- | ------------- |
| Example 1     | Generic OnOff Server  |
| Example 5     | Adding OnOff and Lightness in two elements |
| Example 6     | Adding vendor specific model |
| Example 7     | Generic OnOff Client as Provisioner |
| Example 8     | Generic OnOff Server on GATT Bearer + Proxy Feature |
| Example 9     | Generic OnOff Client on GATT Bearer + Proxy Feature |
| Example 10    | Generic OnOff Server + LPN/Friend Feature |
| Example 11    | Generic OnOff Server on GATT Bearer + LPN/Friend Feature |