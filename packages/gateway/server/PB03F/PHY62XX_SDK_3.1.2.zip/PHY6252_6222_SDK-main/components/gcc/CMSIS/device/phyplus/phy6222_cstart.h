

#ifndef __ARCH_ARM_SRC_PHY62XX_START_H
#define __ARCH_ARM_SRC_PHY62XX_START_H


#ifndef __ASSEMBLY__
#ifdef __cplusplus
extern "C"
{
#endif


#ifdef __cplusplus
}
#endif
#endif /* __ASSEMBLY__ */

#endif /* __ARCH_ARM_SRC_PHY62XX_START_H */
