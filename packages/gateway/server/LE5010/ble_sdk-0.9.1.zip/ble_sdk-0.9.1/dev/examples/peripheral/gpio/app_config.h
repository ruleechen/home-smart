#ifndef APP_CONFIG_H_
#define APP_CONFIG_H_

#define SDK_DEEP_SLEEP_ENABLE 0
#endif
