#ifndef APP_CONFIG_H_
#define APP_CONFIG_H_

#define SDK_USER_TINYFS_NODE_MAX 50
#define SDK_DEEP_SLEEP_ENABLE 0

#define SDK_HCLK_MHZ (16)

#endif
