#ifndef APP_CONFIG_H_
#define APP_CONFIG_H_

#define SDK_HCLK_MHZ (16)

#endif
