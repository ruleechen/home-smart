#ifndef __SIG_MESH_VENDOR_EVENT__
#define __SIG_MESH_VENDOR_EVENT__

void vendor_event_init(void);
void vendor_event_accept_info(uint8_t const *info, uint32_t info_len);

#endif //__SIG_MESH_VENDOR_EVENT__
