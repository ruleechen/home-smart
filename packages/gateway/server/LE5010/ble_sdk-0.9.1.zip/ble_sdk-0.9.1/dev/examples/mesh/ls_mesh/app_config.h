#ifndef APP_CONFIG_H_
#define APP_CONFIG_H_

#define SDK_DEEP_SLEEP_ENABLE 0

#define SDK_MAX_PROFILE_NUM 3

#define SDK_MAX_CONN_NUM 2

#define SDK_HCLK_MHZ (64)
#endif
