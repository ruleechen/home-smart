#include <stdint.h>

const uint8_t fotas_pub_key[64] = {0};
