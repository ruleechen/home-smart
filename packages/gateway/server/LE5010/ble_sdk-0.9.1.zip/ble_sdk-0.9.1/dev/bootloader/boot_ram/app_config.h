#ifndef APP_CONFIG_H_
#define APP_CONFIG_H_
#if defined(LE501X)

#elif defined(SAGI)
#define SDK_HCLK_MHZ (128)
#endif
#endif
