#ifndef LSCRYPT_MSP_H_
#define LSCRYPT_MSP_H_
#include "lscrypt.h"

void HAL_LSCRYPT_MSP_Init(void);
void HAL_LSCRYPT_MSP_Busy_Set(void);
void HAL_LSCRYPT_MSP_Idle_Set(void);
void HAL_LSCRYPT_MSP_DeInit(void);


#endif
