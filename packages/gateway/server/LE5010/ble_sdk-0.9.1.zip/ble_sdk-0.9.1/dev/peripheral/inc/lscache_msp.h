#ifndef LSCACHE_MSP_H_
#define LSCACHE_MSP_H_
#include <stdint.h>

void lscache_msp_init(void);

#endif

