#ifndef LSPIS_MSP_H_
#define LSPIS_MSP_H_
#include "lspis.h"

void HAL_PIS_MSP_Init(void);

void HAL_PIS_MSP_DeInit(void);

#endif
