#ifndef LSIWDG_MSP_H_
#define LSIWDG_MSP_H_

void HAL_IWDG_MSP_Init(void);

#endif
