#ifndef RTC_MSP_H_
#define RTC_MSP_H_

#include "lsrtc.h"

void HAL_MSP_RTC_Init(void);
void HAL_MSP_RTC_DeInit(void);

#endif
