#ifndef LSCACHE_H_
#define LSCACHE_H_
#include <stdint.h>

void lscache_cache_enable(uint8_t prefetch);

#endif
