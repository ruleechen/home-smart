#ifndef REG_CALC_H_
#define REG_CALC_H_
#include "reg_calc_type.h"

#define CALC ((reg_calc_t *)0x50012000)

#endif
