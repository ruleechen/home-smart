#ifndef REG_SYSC_AWO_H_
#define REG_SYSC_AWO_H_
#include "reg_sysc_awo_type.h"

#define SYSC_AWO ((reg_sysc_awo_t *)0x5000D000)

#endif
