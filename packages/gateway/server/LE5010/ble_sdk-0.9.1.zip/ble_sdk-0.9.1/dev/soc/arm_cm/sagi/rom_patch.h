#ifndef ROM_PATCH_H_
#define ROM_PATCH_H_

void rom_patch_init(void);

#endif
