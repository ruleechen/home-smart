#ifndef REG_UART_H_
#define REG_UART_H_
#include "reg_uart_type.h"

#define UART1 ((reg_uart_t *)0x50084000)
#define UART2 ((reg_uart_t *)0x50084800)
#define UART3 ((reg_uart_t *)0x50085000)

#endif
