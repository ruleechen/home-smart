#include "field_manipulate.h"
#include "compile_flag.h"

XIP_BANNED void lscache_sw_reset()
{

}

XIP_BANNED void lscache_clk_set(uint8_t enable)
{

}

