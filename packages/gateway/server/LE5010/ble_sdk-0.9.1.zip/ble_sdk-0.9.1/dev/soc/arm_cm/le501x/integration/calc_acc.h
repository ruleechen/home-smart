#ifndef CALC_ACC_H_
#define CALC_ACC_H_

void calc_acc_init(void);

#endif
