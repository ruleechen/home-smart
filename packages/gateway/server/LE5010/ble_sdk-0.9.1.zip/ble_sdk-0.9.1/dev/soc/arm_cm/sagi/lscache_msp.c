#include "field_manipulate.h"
#include "compile_flag.h"

XIP_BANNED void lscache_msp_init()
{
    
}

