#ifndef REG_RCC_H_
#define REG_RCC_H_
#include "reg_rcc_type.h"

#define RCC ((reg_rcc_t *)0x40021000)

#endif
