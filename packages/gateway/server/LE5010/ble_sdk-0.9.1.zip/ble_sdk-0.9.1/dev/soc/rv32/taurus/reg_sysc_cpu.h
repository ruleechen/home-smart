#ifndef REG_SYSC_CPU_H_
#define REG_SYSC_CPU_H_
#include "reg_sysc_cpu_type.h"

#define SYSC_CPU ((reg_sysc_cpu_t *)0x5000C000)

#endif
