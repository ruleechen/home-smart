#ifndef REG_SYSC_BLE_H_
#define REG_SYSC_BLE_H_
#include "reg_base_addr.h"
#include "reg_sysc_ble_type.h"

#define SYSC_BLE ((reg_sysc_ble_t *)SYSC_BLE_BASE_ADDR)


#endif
