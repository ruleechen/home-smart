#ifndef REG_RF_H_
#define REG_RF_H_
#include "reg_rf_type.h"
#include "reg_base_addr.h"

#define RF ((reg_rf_t *)RF_BASE_ADDR)

#endif
