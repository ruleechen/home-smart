#ifndef LSCACHE_PARAM_H_
#define LSCACHE_PARAM_H_
#include <stdint.h>

void lscache_sw_reset(void);

void lscache_clk_set(uint8_t enable);


#endif

