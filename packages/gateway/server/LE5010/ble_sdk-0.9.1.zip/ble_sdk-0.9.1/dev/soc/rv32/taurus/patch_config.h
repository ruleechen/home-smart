#ifndef PATCH_CONFIG_H_
#define PATCH_CONFIG_H_

#define ROM_PATCH_NUM 16

#endif
