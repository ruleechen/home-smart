#ifndef REG_SYSCFG_H_
#define REG_SYSCFG_H_
#include "reg_syscfg_type.h"

#define SYSCFG ((reg_syscfg_t *)0x40021400)

#endif
