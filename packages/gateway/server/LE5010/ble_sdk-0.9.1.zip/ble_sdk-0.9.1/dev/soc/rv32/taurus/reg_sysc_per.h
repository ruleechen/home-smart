#ifndef REG_SYSC_PER_H_
#define REG_SYSC_PER_H_
#include "reg_sysc_per_type.h"

#define SYSC_PER ((reg_sysc_per_t *)0x50089000)

#endif
