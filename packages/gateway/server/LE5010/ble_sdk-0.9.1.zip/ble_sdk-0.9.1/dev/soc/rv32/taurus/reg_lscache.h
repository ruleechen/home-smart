#ifndef REG_LSCACHE_H_
#define REG_LSCACHE_H_
#include "reg_lscache_type.h"

#define LSCACHE ((reg_lscache_t *)0x5000A000)

#endif

