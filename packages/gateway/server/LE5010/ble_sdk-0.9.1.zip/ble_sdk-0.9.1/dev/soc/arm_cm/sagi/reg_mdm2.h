#ifndef REG_MDM2_H_
#define REG_MDM2_H_
#include "reg_mdm2_type.h"

#define MDM2 ((reg_mdm2_t *)0x50019000)

#endif

