#ifndef REG_V33_RG_H_
#define REG_V33_RG_H_
#include "reg_v33_rg_type.h"

#define V33_RG ((reg_v33_rg_t *)0x5000f000)

#endif
