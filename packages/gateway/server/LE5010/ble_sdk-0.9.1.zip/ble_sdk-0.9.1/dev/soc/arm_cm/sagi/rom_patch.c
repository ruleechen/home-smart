#include "lspatch.h"
#include "instructions.h"


void rom_patch_init()
{

}