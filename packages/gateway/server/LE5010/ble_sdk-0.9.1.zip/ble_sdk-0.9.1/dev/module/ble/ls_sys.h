#ifndef LS_SYS_H_
#define LS_SYS_H_

void func_post(void (*func)(void *),void *param);

#endif

